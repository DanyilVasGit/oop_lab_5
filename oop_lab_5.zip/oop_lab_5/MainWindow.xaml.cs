﻿using System;
using System.Collections.Generic; // Для Dictionary
using System.Linq; // Для LINQ (OrderBy)
using System.Text; // Для StringBuilder
using System.Windows; // Для MessageBox
using System.Windows.Controls; // Для TextBox, Button, TextBlock

namespace Lab5_CharCount
{
    /// <summary>
    /// Логіка взаємодії для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Обробник події натискання кнопки "Підрахувати символи".
        /// Зчитує рядок з текстового поля, підраховує кількість кожного символу
        /// та виводить результат у текстовий блок.
        /// </summary>
        /// <param name="sender">Об'єкт, що викликав подію (кнопка).</param>
        /// <param name="e">Аргументи події.</param>
        private void btnCountCharacters_Click(object sender, RoutedEventArgs e)
        {
            lblCharacterCounts.Text = ""; // Очищаємо попередній результат
            lblErrorMessage.Text = "";    // Очищаємо повідомлення про помилку

            string inputString = txtInputString.Text;

            if (string.IsNullOrEmpty(inputString))
            {
                lblErrorMessage.Text = "Будь ласка, введіть рядок для підрахунку.";
                return;
            }

            // Використовуємо Dictionary для зберігання кількості кожного символу
            // Ключ: символ (char), Значення: кількість (int)
            Dictionary<char, int> charCounts = new Dictionary<char, int>();

            // Проходимо по кожному символу в рядку
            foreach (char c in inputString)
            {
                if (charCounts.ContainsKey(c))
                {
                    // Якщо символ вже є в словнику, збільшуємо його лічильник
                    charCounts[c]++;
                }
                else
                {
                    // Якщо символ новий, додаємо його до словника з лічильником 1
                    charCounts.Add(c, 1);
                }
            }

            // Форматуємо результат для виводу
            StringBuilder resultBuilder = new StringBuilder();

            // Сортуємо символи за алфавітом для кращої читабельності
            foreach (var entry in charCounts.OrderBy(pair => pair.Key))
            {
                // Для пробілів та інших невидимих символів можна додати спеціальне відображення
                string charRepresentation = entry.Key.ToString();
                if (entry.Key == ' ')
                {
                    charRepresentation = "[Пробіл]";
                }
                else if (char.IsControl(entry.Key)) // Для інших керуючих символів
                {
                    charRepresentation = $"[Контрольний символ: {(int)entry.Key}]";
                }
                else if (char.IsWhiteSpace(entry.Key) && entry.Key != ' ') // Для інших пробільних символів крім пробілу
                {
                    charRepresentation = $"[Пробільний символ: '{(int)entry.Key}']";
                }


                resultBuilder.AppendLine($"'{charRepresentation}' : {entry.Value} разів");
            }

            lblCharacterCounts.Text = resultBuilder.ToString();
        }
    }
}
